<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Anggota</title>
    <center><h1 class="sub-header">Laporan Data Transaksi</h1></center>
</head>

<body>
<div class="card-body">
  <form class="form-horizontal" role="form" enctype="multipart/form-data" action="laporan/laporan_transaksiproses.php" method="POST">
      
        <button type="submit" name="tombol" value="tampil" class="btn ink-reaction btn-primary">Cetak</button>
                <button type="button" namae="tombol" value="tampil" class="btn ink-reaction btn-primary" onclick="self.history.back()">Kembali</button></p>

      </div><br>
  </form>
</div>
</body>
</html>